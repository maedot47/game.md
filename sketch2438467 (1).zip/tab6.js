// let displayText = "3:15";  
// let inputText = "";        
// let timer = 0;             
// let microwaveOn = false;   
// let doorOpen = false;      
// let microwavePlateVisible = false; 
// let plateRotation = 0;     
// let foodOnPlate = null;    

// let foodTypes = ["Pizza", "Burger", "Soup", "Noodle"];  
// let selectedFoodIndex = -1;  

// let foodImages = [];  
// let spinSound;   
// let endSound;     
// let clickSound;   
// let windowX = 80;  
// let windowWidth = 340;  
// let doorAngle = 0;  
// let handleOffset = 150;

// function preload() {
//   foodImages[0] = loadImage('pizza.jpg');  
//   foodImages[1] = loadImage('burger.jpg');
//   foodImages[2] = loadImage('soup.avif');
//   foodImages[3] = loadImage('noodle.avif');
  
//   // Load the sound files
//   spinSound = loadSound('ART&SFX - Microwave.wav');  
//   endSound = loadSound('microwave-finished-82491.mp3');    
//   clickSound = loadSound('microwave-button-82493.mp3');  
// }

// function setup() {
//   createCanvas(800, 450);  
// }

// // Main drawing function
// function draw() {
//   background(220);          
//   drawMicrowave();          
//   drawButtons();            
//   drawDisplay();            
//   drawShelf();             

//   if (microwaveOn && timer > 0) {
//     timer -= 1;
//     displayText = formatTime(timer);

//     plateRotation += 0.05;  // Rotate the plate slowly (increment rotation value)

//     // Play the spin sound only if it's not already playing
//     if (!spinSound.isPlaying()) {
//       spinSound.play();  // Start the spin sound if it's not already playing
//     }
//   }

//   // Timer has reached 0
//   if (timer <= 0 && microwaveOn) {
//     microwaveOn = false;  
//     displayText = "End";  // Display "End" when the timer reaches 0
    
//     // Stop the spin sound and play the end sound
//     spinSound.stop();  // Stop the spin sound once the timer ends
//     if (!endSound.isPlaying()) {
//       endSound.play();  // Play the end sound once when the timer reaches 0
//     }
//   }
// }

// function drawDisplay() {
//   fill(0);
//   rect(470, 60, 120, 50);  
//   fill(0, 255, 0);  // Green color for the display text
//   textSize(26);
//   textAlign(CENTER, CENTER);
//   text(displayText, 530, 85);  
// }

// function formatTime(time) {
//   let minutes = int(time / 60);
//   let seconds = int(time % 60);
//   return nf(minutes, 1) + ":" + nf(seconds, 2);
// }

// function parseTime(input) {
//   let parts = input.split(":");
//   let minutes = int(parts[0] || 0);
//   let seconds = int(parts[1] || 0);
//   return minutes * 60 + seconds;
// }

// function drawMicrowave() {
//   fill(150);
//   rect(70, 40, 620, 600, 10); // Microwave frame
  
//   fill(200, 200, 255, 100);  
//   rect(80, 60, 340, 320); // Microwave interior
  
//   // Handle the door rotation animation
//   if (doorOpen) {
//     doorAngle = lerp(doorAngle, -PI / 2, 0.1);  // Smoothly rotate the door open
//     windowX = lerp(windowX, 80 - 340, 0.1);  // Slide the window to the left when the door opens
//   } else {
//     doorAngle = lerp(doorAngle, 0, 0.1);  // Smoothly rotate the door closed
//     windowX = lerp(windowX, 80, 0.1);  // Slide the window back to the right when the door closes
//   }

//   // Draw the door (rotate based on the angle)
//   push();
//   translate(430, 130);  // Move to the hinge point
//   rotate(doorAngle);  // Rotate the door around the hinge
//   fill(100);
//   rect(0, 0, 25, 180, 5);  // Door itself
//   pop();

//   // Draw the window (glass) part
//   fill(255, 255, 255, 150);  // Semi-transparent white to simulate the window
//   rect(windowX, 60, windowWidth, 320); // This is the sliding window part

//   // Draw the handle ON the window ONLY when the door is open
//   if (doorOpen) {
//     fill(100);
//     rect(windowX + handleOffset, 200, 30, 60);  // Handle on the window when it's open
//   }

//   // If the door is open and the plate is visible, draw the rotating plate
//   if (doorOpen && microwavePlateVisible) {
//     push();  
//     translate(250, 250);  // Move to the center of the microwave
//     rotate(plateRotation);  // Apply rotation to the plate ONLY
    
//     fill(255);  
//     stroke(0);  
//     strokeWeight(4);
//     ellipse(0, 0, 150, 150);  // Draw the rotating plate
//     pop();  // End rotation of the plate

//     // Draw the food image at the center (no rotation applied to food)
//     if (foodOnPlate !== null) {
//       push();
//       imageMode(CENTER);
//       image(foodImages[selectedFoodIndex], 250, 250, 100, 100);  // Food image at the center of the plate
//       pop();
//     }
//   }
// }

// function drawButtons() {
//   fill(200);
//   textAlign(CENTER, CENTER);
//   textSize(12);

//   let buttonWidth = 70;
//   let buttonHeight = 20;
//   let horizontalSpacing = 70;
//   let verticalSpacing = 40;
//   let xStart = 470;
//   let yStart = 118;

//   let buttonLabels = [
//     ["Popcorn", "Minute Plus"], ["1", "2", "3"], ["4", "5", "6"],
//     ["7", "8", "9"], ["PowerLevel", "0", "TimerClock"], ["Stop", "Start"],
//     ["Cook", "Defrost", "Reheat"], ["Melt", "Soften"]
//   ];

//   for (let row = 0; row < buttonLabels.length; row++) {
//     for (let col = 0; col < buttonLabels[row].length; col++) {
//       let x = xStart + col * horizontalSpacing;
//       let y = yStart + row * verticalSpacing;
//       if (mouseX > x && mouseX < x + buttonWidth && mouseY > y && mouseY < y + buttonHeight) {
//         let button = buttonLabels[row][col];
//         clickSound.play();  // Play the button click sound
//         if (button >= '0' && button <= '9') {
//           inputText += button;  
//           displayText = formatTime(inputText);  
//         }
//         else if (button === "Stop") {
//           microwaveOn = false;
//           inputText = "";  
//           displayText = "3:15";  // Reset to default display
//         } else if (button === "Start") {
//           microwaveOn = true;
//           timer = parseTime(inputText);  
//           inputText = "";  // Clear input
//           displayText = formatTime(timer);  
//         }
//       }
//     }
//   }

//   if (mouseX > 80 && mouseX < 420 && mouseY > 60 && mouseY < 380) {
//     doorOpen = !doorOpen;
//     if (doorOpen) {
//       microwavePlateVisible = true;
//     } else {
//       microwavePlateVisible = false;
//     }
//   }

//   // Check if a food option was clicked on the shelf
//   if (mouseX > 700 && mouseX < 800) {
//     for (let i = 0; i < foodTypes.length; i++) {
//       let y = 100 + i * 35;
//       if (mouseY > y && mouseY < y + 30) {
//         selectedFoodIndex = i;  // Set the selected food index
//         foodOnPlate = foodTypes[selectedFoodIndex];  // Place the food on the plate
//       }
//     }
//   }
// }
